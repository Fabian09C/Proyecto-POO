/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

/**
 *
 * @author fabia
 */
public class Pantalones extends Mercancia{
    
    public String colorP;
    public String tallaP;

    public Pantalones(String colorP, String tallaP, String tipoMercancia, int precio) {
        super(tipoMercancia, precio);
        this.colorP = colorP;
        this.tallaP = tallaP;
    }

    public String getColorP() {
        return colorP;
    }

    public String getTallaP() {
        return tallaP;
    }

    public void setColorP(String colorP) {
        this.colorP = colorP;
    }

    public void setTallaP(String tallaP) {
        this.tallaP = tallaP;
    }

    
}
