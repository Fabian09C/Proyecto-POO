/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

/**
 *
 * @author SALA
 */
public class Inventario {
private Camisetas objetoCamisetas1;
private Camisetas objetoCamisetas2;
private Camisetas objetoCamisetas3;
private Camisetas objetoCamisetas4;

private Pantalones objetoPantalones1;
private Pantalones objetoPantalones2;
private Pantalones objetoPantalones3;
private Pantalones objetoPantalones4;

private Chaqueta objetoChaqueta1;
private Chaqueta objetoChaqueta2;
private Chaqueta objetoChaqueta3;
private Chaqueta objetoChaqueta4;

private Zapatos objetoZapatos1;
private Zapatos objetoZapatos2;
private Zapatos objetoZapatos3;
private Zapatos objetoZapatos4;

    

}
