/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyecto;
  import javax.swing.JOptionPane;
/**
 *
 * @author fabia
 */

public class Proyecto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
        //Objetos de venta
        Camisetas objetoCamisetas1 = new Camisetas ("Rojo", "M","Polos",25000);
        Camisetas objetoCamisetas2 = new Camisetas ("Negra", "S","Deportivas",30000);
        Camisetas objetoCamisetas3 = new Camisetas ("Rosada", "M","Abotonadas",60000);
        Camisetas objetoCamisetas4 = new Camisetas ("Cafe", "XS","CropTops",50000);
        
        Pantalones objetoPantalones1 = new Pantalones ("Azul", "30","Pantalones rectos",65000);
        Pantalones objetoPantalones2 = new Pantalones ("Gris", "32","Pantalones pitillo",55000);
        Pantalones objetoPantalones3 = new Pantalones ("Rojo", "28","Leggins",45000);
        Pantalones objetoPantalones4 = new Pantalones ("Negro", "32","Joggers",50000);
        
        Chaqueta objetoChaqueta1 = new Chaqueta ("Beig", "M","Americanas",80000);
        Chaqueta objetoChaqueta2 = new Chaqueta ("Azul", "S","Blazers",70000);
        Chaqueta objetoChaqueta3 = new Chaqueta ("Negra", "M","Moteras",60000);
        Chaqueta objetoChaqueta4 = new Chaqueta ("Azul", "L","Beisboleras",100000);
        
        Zapatos objetoZapatos1 = new Zapatos ("Negra", "40","Botas",85000);
        Zapatos objetoZapatos2 = new Zapatos ("Beig", "35","Americanas",70000);
        Zapatos objetoZapatos3 = new Zapatos ("Cafe", "38","Mocasínes",90000);
        Zapatos objetoZapatos4 = new Zapatos ("Rojo", "42","Zapatillas",120000);
        
        //Contador del total a pagar
        int contador=0;
        
        //Ingreso usuario y contraseña
        int Usuario = Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese el usuario: "));
        int Contraseña = Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese la contraseña: "));
        if(Usuario==12345){
        if(Contraseña==6789){
        JOptionPane.showMessageDialog(null,"Bienvenido a la tienda de ropa");
        //Ingreso programa
        char continuar='s';
            while(continuar=='s'){
                String entrada=JOptionPane.showInputDialog(null,"¿Que quieres comprar?"+"1.Camisetas"+"\n2.Pantalones"+"\n3.Chaquetas"+"\n4.Zapatos");
                int num=Integer.parseInt(entrada);
                //Ingreso a camisetas
                    if(num==1){
                    String entrada1 = JOptionPane.showInputDialog(null,"Escoge el tipo de camiseta."+"\n1."+objetoCamisetas1.getTipoMercancia()+"\n2."+objetoCamisetas2.getTipoMercancia()+"\n3."+objetoCamisetas3.getTipoMercancia()+"\n4."+objetoCamisetas4.getTipoMercancia());
                    int num1=Integer.parseInt(entrada1);
                        if(num1==1){
                            contador=contador+objetoCamisetas1.getPrecio();
                            JOptionPane.showMessageDialog(null, objetoCamisetas1.getPrecio()+objetoCamisetas1.getColorC()+objetoCamisetas1.getTallaC());
                            }
                        else if(num1==2){
                            contador=contador+objetoCamisetas2.getPrecio();
                            JOptionPane.showMessageDialog(null, objetoCamisetas2.getPrecio()+objetoCamisetas2.getColorC()+objetoCamisetas2.getTallaC());
                        }
                        else if(num1==3){
                            contador=contador+objetoCamisetas3.getPrecio();
                            JOptionPane.showMessageDialog(null, objetoCamisetas3.getPrecio()+objetoCamisetas3.getColorC()+objetoCamisetas3.getTallaC());
                        }
                        else if (num1==4){
                            contador=contador+objetoCamisetas4.getPrecio();
                            JOptionPane.showMessageDialog(null, objetoCamisetas4.getPrecio()+objetoCamisetas4.getColorC()+objetoCamisetas4.getTallaC());
                        }               
                    }     
                    //Ingreso a pantalones
                    else if(num==2){
                    String entrada1 = JOptionPane.showInputDialog(null,"Escoge el tipo de pantalon."+"\n1."+objetoPantalones1.getTipoMercancia()+"\n2."+objetoPantalones2.getTipoMercancia()+"\n3."+objetoPantalones3.getTipoMercancia()+"\n4."+objetoPantalones4.getTipoMercancia());
                   
                        int num1=Integer.parseInt(entrada1);
                        if(num1==1){
                            contador=contador+objetoPantalones1.getPrecio();
                            JOptionPane.showMessageDialog(null, objetoPantalones1.getPrecio()+objetoPantalones1.getColorP()+objetoPantalones1.getTallaP());
                            }
                        else if(num1==2){
                            contador=contador+objetoPantalones2.getPrecio();
                            JOptionPane.showMessageDialog(null, objetoPantalones2.getPrecio()+objetoPantalones2.getColorP()+objetoPantalones2.getTallaP());
                            } 
                        else if(num1==3){
                            contador=contador+objetoPantalones3.getPrecio();
                            JOptionPane.showMessageDialog(null, objetoPantalones3.getPrecio()+objetoPantalones3.getColorP()+objetoPantalones3.getTallaP());
                            }                                       
                        else if (num1==4){
                            contador=contador+objetoPantalones4.getPrecio();
                            JOptionPane.showMessageDialog(null, objetoPantalones4.getPrecio()+objetoPantalones4.getColorP()+objetoPantalones4.getTallaP());
                            }
                        }   
                        //Ingreso a chaquetas
                        else if(num==3){
                        String entrada1 = JOptionPane.showInputDialog(null,"Escoge el tipo de chaqueta."+"\n1."+objetoChaqueta1.getTipoMercancia()+"\n2."+objetoChaqueta2.getTipoMercancia()+"\n3."+objetoChaqueta3.getTipoMercancia()+"\n4."+objetoChaqueta4.getTipoMercancia());
                   
                        int num1=Integer.parseInt(entrada1);
                        if(num1==1){
                            contador=contador+objetoChaqueta1.getPrecio();
                            JOptionPane.showMessageDialog(null, objetoChaqueta1.getPrecio()+objetoChaqueta1.getColorCh()+objetoChaqueta1.getTallaCh());
                            }
                        else if(num1==2){
                            contador=contador+objetoChaqueta2.getPrecio();
                            JOptionPane.showMessageDialog(null, objetoChaqueta2.getPrecio()+objetoChaqueta2.getColorCh()+objetoChaqueta2.getTallaCh());
                            } 
                        else if(num1==3){
                            contador=contador+objetoChaqueta3.getPrecio();
                            JOptionPane.showMessageDialog(null, objetoChaqueta3.getPrecio()+objetoChaqueta3.getColorCh()+objetoChaqueta3.getTallaCh());
                            }                                       
                        else if (num1==4){
                            contador=contador+objetoChaqueta4.getPrecio();
                            JOptionPane.showMessageDialog(null, objetoChaqueta4.getPrecio()+objetoChaqueta4.getColorCh()+objetoChaqueta4.getTallaCh());
                            }
                    }
                       //Ingreso a zapatos
                        else if(num==4){
                        String entrada1 = JOptionPane.showInputDialog(null,"Escoge el tipo de zapatos."+"\n1."+objetoZapatos1.getTipoMercancia()+"\n2."+objetoZapatos2.getTipoMercancia()+"\n3."+objetoZapatos3.getTipoMercancia()+"\n4."+objetoZapatos4.getTipoMercancia());
                   
                        int num1=Integer.parseInt(entrada1);
                        if(num1==1){
                            contador=contador+objetoZapatos1.getPrecio();
                            JOptionPane.showMessageDialog(null, objetoZapatos1.getPrecio()+objetoZapatos1.getColorT()+objetoZapatos1.getTallaT());
                            }
                        else if(num1==2){
                            contador=contador+objetoZapatos2.getPrecio();
                            JOptionPane.showMessageDialog(null, objetoZapatos2.getPrecio()+objetoZapatos2.getColorT()+objetoZapatos2.getTallaT());
                            } 
                        else if(num1==3){
                            contador=contador+objetoZapatos3.getPrecio();
                            JOptionPane.showMessageDialog(null, objetoZapatos3.getPrecio()+objetoZapatos3.getColorT()+objetoZapatos3.getTallaT());
                            }                                       
                        else if (num1==4){
                            contador=contador+objetoZapatos4.getPrecio();
                            JOptionPane.showMessageDialog(null, objetoZapatos4.getPrecio()+objetoZapatos4.getColorT()+objetoZapatos4.getTallaT());
                            }
                    }
                    //Volver a comprar
                    continuar=JOptionPane.showInputDialog(null, "¿Quiere seguir comprando? s/n").charAt(0); 
                    }
            //Imprimir el monto a pagar
            System.out.println("Este es el monto a pagar $"+contador);
        }
        //Cierre de programa si usuario o contraseña esta mal
         if(Usuario!=12345){
            if(Contraseña!=6789){
                JOptionPane.showMessageDialog(null,"Usuario o contraseña incorrectos");
                JOptionPane.showMessageDialog(null,"Vuelva a iniciar el programa");
                System.exit(0);
        }
    }
}
}
}
        
            
        
        






   
