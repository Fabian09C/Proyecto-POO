/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

/**
 *
 * @author fabia
 */
public class Zapatos extends Mercancia{
    
    public String tallaT;
    public String colorT;

    public Zapatos(String tallaT, String colorT, String tipoMercancia, int precio) {
        super(tipoMercancia, precio);
        this.tallaT = tallaT;
        this.colorT = colorT;
    }

    public String getTallaT() {
        return tallaT;
    }

    public String getColorT() {
        return colorT;
    }

    public void setTallaT(String tallaT) {
        this.tallaT = tallaT;
    }

    public void setColorT(String colorT) {
        this.colorT = colorT;
    }

    
}
