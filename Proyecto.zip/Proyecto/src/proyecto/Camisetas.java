/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import javax.swing.JOptionPane;

/**
 *
 * @author fabia
 */
public class Camisetas extends Mercancia{
    
    public String colorC;
    public String tallaC;

    public Camisetas(String colorC, String tallaC, String tipoMercancia, int precio) {
        super(tipoMercancia, precio);
        this.colorC = colorC;
        this.tallaC = tallaC;
    }

    public String getColorC() {
        return colorC;
    }

    public String getTallaC() {
        return tallaC;
    }

    public void setColorC(String colorC) {
        this.colorC = colorC;
    }

    public void setTallaC(String tallaC) {
        this.tallaC = tallaC;
    }
    
}


