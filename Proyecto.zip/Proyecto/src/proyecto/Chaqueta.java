/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

/**
 *
 * @author fabia
 */
public class Chaqueta extends Mercancia{
    
    public String tallaCh;
    public String colorCh;

    public Chaqueta(String tallaCh, String colorCh, String tipoMercancia, int precio) {
        super(tipoMercancia, precio);
        this.tallaCh = tallaCh;
        this.colorCh = colorCh;
    }

    public String getTallaCh() {
        return tallaCh;
    }

    public String getColorCh() {
        return colorCh;
    }

    public void setTallaCh(String tallaCh) {
        this.tallaCh = tallaCh;
    }

    public void setColorCh(String colorCh) {
        this.colorCh = colorCh;
    }

    
}
