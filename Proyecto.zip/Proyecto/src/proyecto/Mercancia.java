/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

/**
 *
 * @author fabia
 */
public abstract class Mercancia {
    private String tipoMercancia;
    private int precio;    
    
     public Mercancia(String tipoMercancia, int precio) {
        this.tipoMercancia=tipoMercancia;
        this.precio=precio;
    }

    public String getTipoMercancia() {
        return tipoMercancia;
    }

    public int getPrecio() {
        return precio;
    }

    public void setTipoMercancia(String tipoMercancia) {
        this.tipoMercancia = tipoMercancia;
    }
    public void setPrecio(int precio) {
        this.precio = precio;
    }   
}
    

